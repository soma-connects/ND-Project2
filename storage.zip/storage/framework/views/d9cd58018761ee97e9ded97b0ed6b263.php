<!-- resources/views/home.blade.php -->
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Home','bodyclass' => 'home']); ?>
    <section class="hero" style="background: url('<?php echo e(asset('assets/img/shroom6.jpg')); ?>') no-repeat center center/cover;">
        <div class="hero-content container">
            <h1>Welcome to Paws, Petals & Fungi</h1>
            <p class="hero-subtitle">Natural pet care, premium mushrooms, and vibrant flowers for a healthier, happier life.</p>
            <a href="<?php echo e(route('shop')); ?>" class="btn btn-primary">Shop Now</a>
        </div>
    </section>

    <section class="featured-products">
        <div class="container">
            <h2>Our Featured Products</h2>
            <p class="section-subtitle">Handpicked for you and your pets.</p>
            <div class="product-grid">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="product-card">
                        <?php if($product->is_new || $product->is_on_sale): ?>
                            <span class="product-badge"><?php echo e($product->is_new ? 'New' : 'Sale'); ?></span>
                        <?php endif; ?>
                        <a href="<?php echo e(route('product', $product->id)); ?>">
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-200 object-cover rounded" loading="lazy" onerror="this.src='https://placehold.co/300x300/cccccc/000000?text=Image+Not+Found'">
                            <h3><?php echo e($product->name); ?></h3>
                            <p class="price">$<?php echo e(number_format($product->price, 2)); ?></p>
                            
                        </a>
                        <p class="sku">SKU: <?php echo e($product->sku ?? 'N/A'); ?></p>
                        <?php if($product->stock < 5 && $product->stock > 0): ?>
                            <p class="stock-info">Only <?php echo e($product->stock); ?> left in stock!</p>
                        <?php elseif($product->stock == 0): ?>
                            <p class="stock-info out-of-stock">Out of Stock</p>
                        <?php endif; ?>
                        <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="add-to-cart-form" data-product-id="<?php echo e($product->id); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <input type="number" name="quantity" value="1" min="1" max="<?php echo e($product->stock); ?>" class="quantity-selector-small input">
                            <button type="submit" class="btn-primary add-to-cart" <?php echo e($product->stock == 0 ? 'disabled' : ''); ?>>Add to Cart</button>
                        </form>
                        
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No featured products available.</p>
                <?php endif; ?>
            </div>
            <div class="view-all">
                <a href="<?php echo e(route('shop')); ?>" class="btn btn-secondary">View All Products</a>
            </div>
        </div>
    </section>

   <section class="categories-section">
    <div class="container">
        <h2>Explore Our Collections</h2>
        <p class="section-subtitle">Discover our curated range of pet care, mushrooms, and flowers.</p>
        <div class="category-grid">
            <a href="<?php echo e(route('cap')); ?>" class="category-item">
                <img src="<?php echo e(asset('assets/img/hero.webp')); ?>" alt="Caps" loading="lazy">
                <h3>Mushroom Capsules</h3>
                <p>Boost wellness with our premium capsules.</p>
            </a>
            <a href="<?php echo e(route('sheet')); ?>" class="category-item">
                <img src="<?php echo e(asset('assets/img/shroom3.jpg')); ?>" alt="Sheets" loading="lazy">
                <h3>Pet Sheets</h3>
                <p>Calming, natural sheets for your pets.</p>
            </a>
            <a href="<?php echo e(route('shroom')); ?>" class="category-item">
                <img src="<?php echo e(asset('assets/img/shroom7.jpg')); ?>" alt="Shrooms" loading="lazy">
                <h3>Mushroom Powders</h3>
                <p>Nutrient-rich powders for health.</p>
            </a>
        </div>
    </div>
</section>

    <section class="about-section" style="background: url('<?php echo e(asset('assets/img/about.webp')); ?>') no-repeat center center/cover;">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>About Paws, Petals & Fungi</h2>
                    <p>We’re passionate about natural living, blending pet care, medicinal mushrooms, and vibrant flowers to enrich lives. Our products are sustainably sourced, crafted with love, and designed to bring joy to you and your furry friends.</p>
                    <a href="<?php echo e(route('aboutus')); ?>" class="btn btn-primary">Learn More</a>
                </div>
                <div class="about-image">
                    <img src="<?php echo e(asset('assets/img/default.png')); ?>" alt="About Us" loading="lazy">
                </div>
            </div>
        </div>
    </section>

    <section class="testimonials-section">
        <div class="container">
            <h2>What Our Customers Say</h2>
            <p class="section-subtitle">Hear from our happy pet owners and wellness enthusiasts.</p>
            <div class="testimonials-grid">
                <div class="testimonial-item">
                    <p>"The Cordyceps Capsules gave me such an energy boost! My dog loves the Wildflower Treats too."</p>
                    <h4>Sarah M.</h4>
                    <span class="stars">★★★★★</span>
                </div>
                <div class="testimonial-item">
                    <p>"The Chamomile Pet Sheet keeps my cat calm during storms. Amazing quality!"</p>
                    <h4>James T.</h4>
                    <span class="stars">★★★★★</span>
                </div>
                <div class="testimonial-item">
                    <p>"Beautiful Marigold Bouquet and fast delivery. Will shop again!"</p>
                    <h4>Emma L.</h4>
                    <span class="stars">★★★★★</span>
                </div>
            </div>
        </div>
    </section>

    

    <script>
        document.querySelectorAll('.add-to-cart-form').forEach(form => {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(form);
                try {
                    const response = await fetch(form.action, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Accept': 'application/json'
                        },
                        body: formData
                    });
                    const data = await response.json();
                    if (data.success) {
                        document.querySelector('.cart-count').textContent = data.cartCount;
                        showNotification(data.message || 'Product added to cart.', 'success');
                    } else {
                        showNotification(data.message || 'Failed to add to cart.', 'error');
                    }
                } catch (error) {
                    showNotification('An error occurred while adding to cart.', 'error');
                }
            });
        });

        function showNotification(message, type = 'success') {
            const notification = document.createElement('div');
            notification.className = `alert alert-${type}`;
            notification.textContent = message;
            document.querySelector('.container').prepend(notification);
            setTimeout(() => notification.remove(), 3000);
        }

        document.querySelectorAll('.close').forEach(button => {
            button.addEventListener('click', function () {
                const alert = this.parentElement;
                alert.classList.add('fade-out');
                setTimeout(() => alert.remove(), 500);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\wamp65\www\ND-Project\resources\views/home/index.blade.php ENDPATH**/ ?>