<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-column">
                <h4>Shop</h4>
                <ul>
                    <li><a href="<?php echo e(route('cap')); ?>">Caps</a></li>
                    <li><a href="<?php echo e(route('shroom')); ?>">Shrooms</a></li>
                    <li><a href="<?php echo e(route('sheet')); ?>">Sheets</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4>Our Company</h4>
                <ul>
                    <li><a href="<?php echo e(route('aboutus')); ?>">About Us</a></li>
                    <li><a href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h4>Join Our Community</h4>
                <p>Get exclusive updates, offers, and insights.</p>
                <form class="newsletter-form" method="POST" action="<?php echo e(route('newsletter.subscribe')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="email" name="email" placeholder="Enter your email" required>
                    <button type="submit" class="btn-primary">Subscribe</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            
            <div class="copyright">
                © <?php echo e(date('Y')); ?> Paws, Petals & Fungi. All Rights Reserved.
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\wamp65\www\ND-Project\resources\views/components/layouts/footer.blade.php ENDPATH**/ ?>