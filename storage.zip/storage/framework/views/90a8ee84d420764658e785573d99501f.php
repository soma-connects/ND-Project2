<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Sheets','bodyclass' => 'sheet']); ?>
    <div class="container px-4 py-8">
        <h2 class="text-4xl font-bold mb-8 mt-5 btn text-accent text-center font-playfair">Sheets</h2>

        <!-- Notifications -->
        <?php if(session('success')): ?>
            <div class="alert alert-success mb-6 flex justify-between items-center">
                <?php echo e(session('success')); ?>

                <button class="close text-white">×</button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger mb-6 flex justify-between items-center">
                <?php echo e(session('error')); ?>

                <button class="close text-white">×</button>
            </div>
        <?php endif; ?>

         <!-- Sorting Controls -->
        <div class="sort-controls">
            <form action="<?php echo e(route('sheet')); ?>" method="GET">
                <select name="sort" onchange="this.form.submit()">
                    <option value="">Sort By</option>
                    <option value="price-asc" <?php echo e(request('sort') == 'price-asc' ? 'selected' : ''); ?>>Price: Low to High</option>
                    <option value="price-desc" <?php echo e(request('sort') == 'price-desc' ? 'selected' : ''); ?>>Price: High to Low</option>
                    <option value="name-asc" <?php echo e(request('sort') == 'name-asc' ? 'selected' : ''); ?>>Name: A-Z</option>
                    <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Newest</option>
                </select>
            </form>
        </div>    

        <?php if($products->isEmpty()): ?>
            <p class="text-gray-600 dark:text-gray-400 text-center py-12">No products found.</p>
        <?php else: ?>
            <div class="product-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-card">
                        <?php if($product->is_new): ?>
                            <span class="product-badge">New</span>
                        <?php endif; ?>
                        <?php if($product->is_on_sale): ?>
                            <span class="product-badge sale">Sale</span>
                        <?php endif; ?>
                        <a href="<?php echo e(route('product', $product->id)); ?>">
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-200 object-cover rounded" loading="lazy" onerror="this.src='https://placehold.co/300x200/cccccc/000000?text=Image+Not+Found'">
                        </a>
                        <div class="product-card-content">
                            <a href="<?php echo e(route('product', $product->id)); ?>">
                                <h3><?php echo e($product->name); ?></h3>
                            </a>
                            <p class="sku"><?php echo e($product->sku ?? 'N/A'); ?></p>
                            <p class="price">$<?php echo e(number_format($product->price, 2)); ?></p>
                            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="add-to-cart-form" data-product-id="<?php echo e($product->id); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="quantity-selector-small">
                                    <input type="number" name="quantity" value="1" min="1" max="<?php echo e($product->stock); ?>" class="input">
                                    <button type="submit" class="btn-primary add-to-cart" <?php echo e($product->stock == 0 ? 'disabled' : ''); ?>>Add to Cart</button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-8 flex justify-center">
                <?php echo e($products->links('vendor.pagination.custom')); ?>

            </div>
        <?php endif; ?>
    </div>

    <script>
        document.querySelectorAll('.add-to-cart-form').forEach(form => {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(form);
                try {
                    const response = await fetch(form.action, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Accept': 'application/json'
                        },
                        body: formData
                    });
                    const data = await response.json();
                    if (data.success) {
                        document.querySelector('.cart-count').textContent = data.cartCount;
                        showNotification(data.message || 'Product added to cart.', 'success');
                    } else {
                        showNotification(data.message || 'Failed to add to cart.', 'error');
                    }
                } catch (error) {
                    showNotification('An error occurred while adding to cart.', 'error');
                }
            });
        });

        function showNotification(message, type = 'success') {
            const notification = document.createElement('div');
            notification.className = `alert alert-${type} mb-6 flex justify-between items-center`;
            notification.innerHTML = `${message}<button class="close text-white">×</button>`;
            document.querySelector('.container').prepend(notification);
            setTimeout(() => notification.remove(), 3000);

            document.querySelectorAll('.close').forEach(button => {
                button.addEventListener('click', function () {
                    const alert = this.parentElement;
                    alert.classList.add('fade-out');
                    setTimeout(() => alert.remove(), 500);
                });
            });
        }

        document.querySelectorAll('.close').forEach(button => {
            button.addEventListener('click', function () {
                const alert = this.parentElement;
                alert.classList.add('fade-out');
                setTimeout(() => alert.remove(), 500);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\wamp65\www\ND-Project\resources\views/sheet.blade.php ENDPATH**/ ?>