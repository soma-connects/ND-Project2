<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ? "$title | " : ''); ?>Paws, Petals & Fungi - Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <script src="https://kit.fontawesome.com/yourkit.js" crossorigin="anonymous"></script>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- Vendor CSS Files -->
    
    <link href="<?php echo e(asset('assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
</head>
<body class="admin">
    <div class="flex min-h-screen">
            <button class="menu-toggle toggle-edit" aria-expanded="false">
                    <i class="fas fa-bars"></i>
            </button>
        <aside class="sidebar" id="sidebar">
            
            <div class="sidebar-header">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar-brand">
                    <i class="fas fa-leaf"></i>
                    <span>Shroom Admin</span>
                </a>
            </div>
            <nav class="sidebar-menu">
                <div class="menu-title">Management</div>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="menu-item"><i class="fas fa-box"></i><span>Products</span></a>
                <a href="<?php echo e(route('admin.user-carts.index')); ?>" class="menu-item"><i class="fas fa-shopping-cart"></i><span>User Carts</span></a>
                <a href="<?php echo e(route('admin.payments.index')); ?>" class="menu-item"><i class="fas fa-credit-card"></i><span>Payments</span></a>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="menu-item"><i class="fas fa-users"></i><span>Users</span></a>
                <a href="<?php echo e(route('home')); ?>" class="menu-item"><i class="fas fa-home"></i><span>Home</span></a>
            </nav>
        </aside>
        <main class="main-content">
            <?php echo e($slot); ?>

        </main>
    </div>
    <script src="<?php echo e(asset('app.js')); ?>" defer></script>
</body>
</html><?php /**PATH C:\wamp65\www\ND-Project\resources\views/layouts/base.blade.php ENDPATH**/ ?>