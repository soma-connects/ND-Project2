<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2 = $attributes; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BaseLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Admin Dashboard']); ?>
    <div class="container">
        <h1 class="font-playfair h1-edit ">Admin Dashboard</h1>
        

        <!-- Notifications -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

                <button class="close" onclick="this.parentElement.classList.add('fade-out')">×</button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-error">
                <?php echo e(session('error')); ?>

                <button class="close" onclick="this.parentElement.classList.add('fade-out')">×</button>
            </div>
        <?php endif; ?>

        <!-- Overview Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-title">Total Products</div>
                <div class="stat-value"><?php echo e($totalProducts); ?></div>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="stat-link">Manage Products</a>
            </div>
            <div class="stat-card">
                <div class="stat-title">Pending Orders</div>
                <div class="stat-value"><?php echo e($pendingOrders); ?></div>
                <a href="<?php echo e(route('admin.payments.index')); ?>" class="stat-link">View Orders</a>
            </div>
            <div class="stat-card">
                <div class="stat-title">Total Users</div>
                <div class="stat-value"><?php echo e($totalUsers); ?></div>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="stat-link">Manage Users</a>
            </div>
        </div>

        <!-- Quick Access Links -->
        <div class="quick-actions">
            <h2 class="section-title">Quick Access</h2>
            <div class="action-buttons">
                <a href="<?php echo e(route('admin.products.index')); ?>" class="action-button"><i class="fas fa-box"></i> Manage Products</a>
                <a href="<?php echo e(route('admin.user-carts.index')); ?>" class="action-button"><i class="fas fa-shopping-cart"></i> View User Carts</a>
                <a href="<?php echo e(route('admin.images.index')); ?>" class="action-button"><i class="fas fa-image"></i> Manage Images</a>
                <a href="<?php echo e(route('admin.payments.index')); ?>" class="action-button"><i class="fas fa-credit-card"></i> Manage Payments</a>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="activity-grid">
            <!-- Recent Products -->
            <div class="activity-card">
                <div class="card-header">
                    <h2 class="card-title">Recent Products</h2>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="view-all">View All</a>
                </div>
                <?php if($recentProducts->isEmpty()): ?>
                    <p>No products added yet.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e(ucfirst($product->category)); ?></td>
                                        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="action-link">Edit</a>
                                            <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="action-link delete">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Recent Orders -->
            <div class="activity-card">
                <div class="card-header">
                    <h2 class="card-title">Recent Orders</h2>
                    <a href="<?php echo e(route('admin.payments.index')); ?>" class="view-all">View All</a>
                </div>
                <?php if($recentOrders->isEmpty()): ?>
                    <p>No orders placed yet.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>User</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->user ? $order->user->name : $order->name); ?></td>
                                        <td>$<?php echo e(number_format($order->total, 2)); ?></td>
                                        <td>
                                            <span class="status status-<?php echo e($order->status); ?>"><?php echo e(ucfirst($order->status)); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent User Carts -->
        <div class="activity-card">
            <div class="card-header">
                <h2 class="card-title">Recent User Carts</h2>
                <a href="<?php echo e(route('admin.user-carts.index')); ?>" class="view-all">View All</a>
            </div>
            <?php if($recentCarts->isEmpty()): ?>
                <p>No active user carts.</p>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Total Items</th>
                                <th>Total Value</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentCarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name ?? 'Unknown User'); ?></td>
                                    <td><?php echo e($user->carts->sum('quantity')); ?></td>
                                    <td>
                                        $<?php echo e(number_format($user->carts->sum(function ($cart) {
                                            return $cart->product ? $cart->product->price * $cart->quantity : 0;
                                        }), 2)); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.user-carts.show', $user->id)); ?>" class="action-link">View Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $attributes = $__attributesOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__attributesOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?><?php /**PATH C:\wamp65\www\ND-Project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>