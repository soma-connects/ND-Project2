<header class="site-header">
    <div class="container header-container">
        <div class="logo-left md:logo-center">
            <a href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('assets/img/cover.png')); ?>" class="logo" alt="Paws, Petals & Fungi Logo">
            </a>
        </div>
        <div class="header-actions-left hidden md:flex">
            <a href="<?php echo e(route('shop')); ?>" class="nav-link">Shop</a>
            <a href="<?php echo e(route('cap')); ?>" class="nav-link">Caps</a>
            <a href="<?php echo e(route('sheet')); ?>" class="nav-link">Sheets</a>
            <a href="<?php echo e(route('shroom')); ?>" class="nav-link">Shrooms</a>
            <a href="<?php echo e(route('aboutus')); ?>" class="nav-link">About</a>
        </div>
        <div class="header-actions-right hidden md:flex items-center">
            <a href="<?php echo e(route('contactus')); ?>" class="nav-link">Contact</a>
            <form action="<?php echo e(route('search')); ?>" method="GET" class="search-form">
                <input type="text" name="q" placeholder="Search products..." required>
                <button type="submit" aria-label="Search"><i class="fas fa-search"></i></button>
            </form>
            <a href="<?php echo e(route('cart')); ?>" class="icon-link" aria-label="Shopping Cart">
                <i class="fas fa-shopping-bag"></i>
                <span class="cart-count"><?php echo e($cartCount); ?></span>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role === 'admin'): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">Admin Dashboard</a>
                <?php endif; ?>
                <a href="<?php echo e(route('logout')); ?>" class="icon-link" aria-label="Logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="icon-link" aria-label="Login"><i class="fas fa-user"></i></a>
                <a href="<?php echo e(route('signup')); ?>" class="nav-link">Signup</a>
            <?php endif; ?>
        </div>
        <div class="header-actions-right-mobile md:hidden flex items-center">
            <a href="<?php echo e(route('cart')); ?>" class="icon-link" aria-label="Shopping Cart">
                <i class="fas fa-shopping-bag"></i>
                <span class="cart-count"><?php echo e($cartCount); ?></span>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('logout')); ?>" class="icon-link" aria-label="Logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="icon-link" aria-label="Login"><i class="fas fa-user"></i></a>
            <?php endif; ?>
        </div>
        <button class="menu-toggle md:hidden" aria-label="Toggle menu" aria-expanded="false">
            <i class="fas fa-bars"></i>
        </button>
    </div>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav-backdrop" id="mobile-nav-backdrop"></div>
    <nav class="mobile-nav" id="mobile-nav">
        <a href="<?php echo e(route('shop')); ?>" class="nav-link">Shop All</a>
        <a href="<?php echo e(route('cap')); ?>" class="nav-link">Caps</a>
        <a href="<?php echo e(route('sheet')); ?>" class="nav-link">Sheets</a>
        <a href="<?php echo e(route('shroom')); ?>" class="nav-link">Shrooms</a>
        <a href="<?php echo e(route('aboutus')); ?>" class="nav-link">About</a>
        <a href="<?php echo e(route('contactus')); ?>" class="nav-link">Contact</a>
        <a href="<?php echo e(route('cart')); ?>" class="nav-link">Cart (<?php echo e($cartCount); ?>)</a>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">Admin Dashboard</a>
            <?php endif; ?>
            <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); document.getElementById('mobile-logout-form').submit();">Logout</a>
            <form id="mobile-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a>
            <a href="<?php echo e(route('signup')); ?>" class="nav-link">Signup</a>
        <?php endif; ?>
        <form action="<?php echo e(route('search')); ?>" method="GET" class="search-form">
            <input type="text" name="q" placeholder="Search products..." required>
            <button type="submit" aria-label="Search"><i class="fas fa-search"></i></button>
        </form>
    </nav>
</header><?php /**PATH C:\wamp65\www\ND-Project\resources\views/components/layouts/header.blade.php ENDPATH**/ ?>