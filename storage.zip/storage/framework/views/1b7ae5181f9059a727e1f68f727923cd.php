<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($title).'','bodyclass' => ''.e($bodyclass).'']); ?>
    <div class="container px-4 py-8">
        <h1 class="text-4xl font-bold mb-8 mt-5 btn text-accent text-center font-playfair"><?php echo e($product->name); ?></h1>

        <!-- Notifications -->
        <?php if(session('success')): ?>
            <div class="alert alert-success mb-6 flex justify-between items-center">
                <?php echo e(session('success')); ?>

                <button class="close" aria-label="Close alert">×</button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger mb-6 flex justify-between items-center">
                <?php echo e(session('error')); ?>

                <button class="close" aria-label="Close alert">×</button>
            </div>
        <?php endif; ?>

        <!-- Product Details -->
        <div class="product-details">
            <div class="product-image">
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"  loading="lazy" onerror="this.src='https://placehold.co/300x200/cccccc/000000?text=Image+Not+Found'">
                <?php if($product->is_new): ?>
                    <span class="product-badge">New</span>
                <?php endif; ?>
                <?php if($product->is_on_sale): ?>
                    <span class="product-badge sale">Sale</span>
                <?php endif; ?>
            </div>
            <div class="product-info">
                <p class="text-lg"><strong>SKU:</strong> <?php echo e($product->sku ?? 'N/A'); ?></p>
                <p class="text-2xl font-bold text-accent price">$<?php echo e(number_format($product->price, 2)); ?></p>
                <p class="product-description"><?php echo e($product->description); ?></p>
                <p><strong>Category:</strong> <?php echo e(ucfirst($product->category)); ?></p>
                <p class="stock-info"><strong>Stock:</strong> <?php echo e($product->stock > 0 ? $product->stock : 'Out of Stock'); ?></p>
                <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="add-to-cart-form flex items-center gap-4" data-product-id="<?php echo e($product->id); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <input type="number" name="quantity" value="1" min="1" max="<?php echo e($product->stock); ?>" class="quantity-selector-small input">
                    <button type="submit" class="btn btn-primary" <?php echo e($product->stock == 0 ? 'disabled' : ''); ?>>Add to Cart</button>
                </form>
            </div>
        </div>

        <!-- Write-Up Section -->
        <section class="writeup-section">
            <h2 class="font-playfair">Why Buy <?php echo e($product->name); ?>?</h2>
            <p class="product-description text-center">
                Discover the natural power of our mushroom-based products at Paws, Petals & Fungi. 
                <?php echo e($product->name); ?> is crafted with premium, sustainably sourced ingredients to support your wellness journey. 
                Whether you're seeking to boost immunity, enhance focus, or promote relaxation, this product delivers nature’s finest benefits in every dose. 
                Experience the difference with our commitment to quality, purity, and eco-conscious practices.
            </p>
        </section>

        <!-- Recommended Products -->
        <?php if($recommendedProducts && !$recommendedProducts->isEmpty()): ?>
            <section class="recommend-section">
                <h2 class="font-playfair">Explore Similar Products</h2>
                <p class="section-subtitle">Discover more from our <?php echo e(ucfirst($product->category)); ?> collection.</p>
                <div class="product-grid">
                    <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-card">
                            <a href="<?php echo e(route('product', $recommended->id)); ?>" class="product-card-link">
                                <img src="<?php echo e(asset('storage/' . $recommended->image)); ?>" alt="<?php echo e($recommended->name); ?>" class="product-image" loading="lazy" onerror="this.src='https://placehold.co/300x200/cccccc/000000?text=Image+Not+Found'">
                                <?php if($recommended->is_new): ?>
                                    <span class="product-badge">New</span>
                                <?php endif; ?>
                                <?php if($recommended->is_on_sale): ?>
                                    <span class="product-badge sale">Sale</span>
                                <?php endif; ?>
                                <div class="product-card-content">
                                    <h3><?php echo e($recommended->name); ?></h3>
                                    <p class="sku">SKU: <?php echo e($recommended->sku ?? 'N/A'); ?></p>
                                    <p class="price">$<?php echo e(number_format($recommended->price, 2)); ?></p>
                                </div>
                            </a>
                            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="add-to-cart-form" data-product-id="<?php echo e($recommended->id); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($recommended->id); ?>">
                                <div class="quantity-selector-small">
                                    <input type="number" name="quantity" value="1" min="1" max="<?php echo e($recommended->stock); ?>" class="quantity-input">
                                    <button type="submit" class="btn btn-primary" <?php echo e($recommended->stock == 0 ? 'disabled' : ''); ?>>Add to Cart</button>
                                </div>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </div>

    <script>
        document.querySelectorAll('.add-to-cart-form').forEach(form => {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(form);
                const button = form.querySelector('button[type="submit"]');
                button.disabled = true;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';

                try {
                    const response = await fetch(form.action, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Accept': 'application/json'
                        },
                        body: formData
                    });
                    const data = await response.json();
                    if (data.success) {
                        document.querySelector('.cart-count').textContent = data.cartCount;
                        showNotification(data.message || 'Product added to cart!', 'success');
                    } else {
                        showNotification(data.message || 'Failed to add to cart.', 'error');
                    }
                } catch (error) {
                    showNotification('An error occurred while adding to cart.', 'error');
                } finally {
                    button.disabled = false;
                    button.innerHTML = 'Add to Cart';
                }
            });
        });

        function showNotification(message, type = 'success') {
            const notification = document.createElement('div');
            notification.className = `alert alert-${type} mb-6 flex justify-between items-center`;
            notification.innerHTML = `
                ${message}
                <button class="close" aria-label="Close alert">×</button>
            `;
            document.querySelector('.container').prepend(notification);
            setTimeout(() => {
                notification.classList.add('fade-out');
                setTimeout(() => notification.remove(), 500);
            }, 3000);
        }

        document.querySelectorAll('.close').forEach(button => {
            button.addEventListener('click', () => {
                const alert = button.parentElement;
                alert.classList.add('fade-out');
                setTimeout(() => alert.remove(), 500);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\wamp65\www\ND-Project\resources\views/product/show.blade.php ENDPATH**/ ?>